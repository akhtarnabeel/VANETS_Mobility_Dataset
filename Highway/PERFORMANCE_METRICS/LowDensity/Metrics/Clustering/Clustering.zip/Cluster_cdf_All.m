
clc;
clear all;

%{

%% FOR LOG NORMAL MODEL %%

%% for range 500m log model
load All_Neg_Data_Log.mat


AllNeighbours = All_Nodes_L500;

numberOfVehicles = 553;

clusterCountArray = [];
for time = 1005 : 10 :1799
    
    %since we have data till 1799, I am taking 1800 as 1799
    if time == 1800
        time = 1799;
    end
    time
    clusters = {};
    vehicles_T = AllNeighbours{time,1} ; %first colum veh ID and 2nd colum their neighbours
    noOfVeh_T = size(vehicles_T,1);
    
    %cluster_T contains information that will help in identifying cluster
    %1st row contain ID of vehicles
    %2nd row contain if vehicles selected
    %3rd row contains if neighbours of vehicles checked
    cluster_T = zeros(noOfVeh_T,3);
    
    %add nodes to the cluster array
    for i=1: noOfVeh_T
        if (isempty(vehicles_T{i,1}))
        else
            cluster_T(i,1) = vehicles_T{i,1};
        end
    end
    
    %% now check for clusters
    
    checkClusters = 1;
    clusterCount = 0;
    baseId = 0;
    baseNeigh = [];
    while checkClusters == 1
        checkClusters = -1;
        
        %check if the base vehicle exist
        for i= 1:noOfVeh_T
            if cluster_T(i,2) == 0 && cluster_T(i,3) == 0
                %vehicle selected
                cluster_T(i,2) = 1;
                cluster_T(i,3) = 1;
                %add neighbours
                baseId = cluster_T(i,1);
                baseNeigh = vehicles_T{i,2};
                checkClusters = 1;
                clusterCount = clusterCount+1;
                break;
            end
        end
        
        %check if the end has came
        if checkClusters == -1
            
            break;
        end
        
        %mark neighbors of base vehicle
        for i= 1: size(baseNeigh,2)
            selectedId = baseNeigh(1,i);
            %search for the neigh of base vehicle is cluster and mark
            for j = 1 : noOfVeh_T
                if cluster_T(j,1) == selectedId
                    cluster_T(j,2) = 1;
                    break;
                end
            end
        end
        
        clearvars baseNeigh;
        clearvars baseId;
        
        %check for all the vehicles that can be reached from here
        checkAdded = 1;
        while checkAdded == 1
            checkAdded = -1;
            %select the vehicle for base node again
            for i = 1 : noOfVeh_T
                if (cluster_T(i,2) == 1 && cluster_T(i,3) == 0)
                    baseId =  cluster_T(i,1);
                    baseNeigh = vehicles_T{i,2};
                    %base marked
                    cluster_T(i,3) = 1;
                    checkAdded = 1;
                    break;
                end
            end
            
            %check if the end has came
            if checkAdded == -1
                break;
            end
            
            %now again mark the neighbours
            if isempty(baseNeigh)
               %nothing 
            else
                for i= 1: size(baseNeigh,2)
                    selectedId = baseNeigh(1,i);
                    
                    %search for the neigh of base vehicle is cluster and mark
                    for j = 1 : noOfVeh_T
                        if cluster_T(j,1) == selectedId
                            cluster_T(j,2) = 1;
                            break;
                        end
                    end
                end
            end
            
            clearvars baseNeigh;
            clearvars baseId;
            
        end
        
        clearvars baseNeigh;
        clearvars baseId;
        
    end
    
    clusterCountArray = [clusterCountArray clusterCount]
end


clusterCountArray_L500 = clusterCountArray;
save ('clusterCountArray_L500.mat' , 'clusterCountArray_L500');

%% for range 100 Log Model

load All_Neg_Data_Log.mat


AllNeighbours = All_Nodes_L100;




%time = 900 % for this time
%numberOfVehicles = 415; % for time 600 onwards
numberOfVehicles = 553;

clusterCountArray = [];
for time = 1005 : 10 :1799
    
    %since we have data till 1799, I am taking 1800 as 1799
    if time == 1800
        time = 1799;
    end
    time
    clusters = {};
    vehicles_T = AllNeighbours{time,1} ; %first colum veh ID and 2nd colum their neighbours
    noOfVeh_T = size(vehicles_T,1);
    
    %cluster_T contains information that will help in identifying cluster
    %1st row contain ID of vehicles
    %2nd row contain if vehicles selected
    %3rd row contains if neighbours of vehicles checked
    cluster_T = zeros(noOfVeh_T,3);
    
    %add nodes to the cluster array
    for i=1: noOfVeh_T
        if (isempty(vehicles_T{i,1}))
        else
            cluster_T(i,1) = vehicles_T{i,1};
        end
    end
    
    %% now check for clusters
    
    checkClusters = 1;
    clusterCount = 0;
    baseId = 0;
    baseNeigh = [];
    while checkClusters == 1
        checkClusters = -1;
        
        %check if the base vehicle exist
        for i= 1:noOfVeh_T
            if cluster_T(i,2) == 0 && cluster_T(i,3) == 0
                %vehicle selected
                cluster_T(i,2) = 1;
                cluster_T(i,3) = 1;
                %add neighbours
                baseId = cluster_T(i,1);
                baseNeigh = vehicles_T{i,2};
                checkClusters = 1;
                clusterCount = clusterCount+1;
                break;
            end
        end
        
        %check if the end has came
        if checkClusters == -1
            
            break;
        end
        
        %mark neighbors of base vehicle
        for i= 1: size(baseNeigh,2)
            selectedId = baseNeigh(1,i);
            %search for the neigh of base vehicle is cluster and mark
            for j = 1 : noOfVeh_T
                if cluster_T(j,1) == selectedId
                    cluster_T(j,2) = 1;
                    break;
                end
            end
        end
        
        clearvars baseNeigh;
        clearvars baseId;
        
        %check for all the vehicles that can be reached from here
        checkAdded = 1;
        while checkAdded == 1
            checkAdded = -1;
            %select the vehicle for base node again
            for i = 1 : noOfVeh_T
                if (cluster_T(i,2) == 1 && cluster_T(i,3) == 0)
                    baseId =  cluster_T(i,1);
                    baseNeigh = vehicles_T{i,2};
                    %base marked
                    cluster_T(i,3) = 1;
                    checkAdded = 1;
                    break;
                end
            end
            
            %check if the end has came
            if checkAdded == -1
                break;
            end
            
            %now again mark the neighbours
            if isempty(baseNeigh)
               %nothing 
            else
                for i= 1: size(baseNeigh,2)
                    selectedId = baseNeigh(1,i);
                    
                    %search for the neigh of base vehicle is cluster and mark
                    for j = 1 : noOfVeh_T
                        if cluster_T(j,1) == selectedId
                            cluster_T(j,2) = 1;
                            break;
                        end
                    end
                end
            end
            
            clearvars baseNeigh;
            clearvars baseId;
            
        end
        
        clearvars baseNeigh;
        clearvars baseId;
        
    end
    
    clusterCountArray = [clusterCountArray clusterCount]
end


clusterCountArray_L100 = clusterCountArray;
save ('clusterCountArray_L100.mat' , 'clusterCountArray_L100');


%% FOR LOG NORMAL Classical MODEL %%

%% for range 500m log model
load All_Neg_Data_Log_C.mat

AllNeighbours = All_Nodes_L500;

numberOfVehicles = 553;

clusterCountArray = [];
for time = 1005 : 10 :1799
    
    %since we have data till 1799, I am taking 1800 as 1799
    if time == 1800
        time = 1799;
    end
    time
    clusters = {};
    vehicles_T = AllNeighbours{time,1} ; %first colum veh ID and 2nd colum their neighbours
    noOfVeh_T = size(vehicles_T,1);
    
    %cluster_T contains information that will help in identifying cluster
    %1st row contain ID of vehicles
    %2nd row contain if vehicles selected
    %3rd row contains if neighbours of vehicles checked
    cluster_T = zeros(noOfVeh_T,3);
    
    %add nodes to the cluster array
    for i=1: noOfVeh_T
        if (isempty(vehicles_T{i,1}))
        else
            cluster_T(i,1) = vehicles_T{i,1};
        end
    end
    
    %% now check for clusters
    
    checkClusters = 1;
    clusterCount = 0;
    baseId = 0;
    baseNeigh = [];
    while checkClusters == 1
        checkClusters = -1;
        
        %check if the base vehicle exist
        for i= 1:noOfVeh_T
            if cluster_T(i,2) == 0 && cluster_T(i,3) == 0
                %vehicle selected
                cluster_T(i,2) = 1;
                cluster_T(i,3) = 1;
                %add neighbours
                baseId = cluster_T(i,1);
                baseNeigh = vehicles_T{i,2};
                checkClusters = 1;
                clusterCount = clusterCount+1;
                break;
            end
        end
        
        %check if the end has came
        if checkClusters == -1
            
            break;
        end
        
        %mark neighbors of base vehicle
        for i= 1: size(baseNeigh,2)
            selectedId = baseNeigh(1,i);
            %search for the neigh of base vehicle is cluster and mark
            for j = 1 : noOfVeh_T
                if cluster_T(j,1) == selectedId
                    cluster_T(j,2) = 1;
                    break;
                end
            end
        end
        
        clearvars baseNeigh;
        clearvars baseId;
        
        %check for all the vehicles that can be reached from here
        checkAdded = 1;
        while checkAdded == 1
            checkAdded = -1;
            %select the vehicle for base node again
            for i = 1 : noOfVeh_T
                if (cluster_T(i,2) == 1 && cluster_T(i,3) == 0)
                    baseId =  cluster_T(i,1);
                    baseNeigh = vehicles_T{i,2};
                    %base marked
                    cluster_T(i,3) = 1;
                    checkAdded = 1;
                    break;
                end
            end
            
            %check if the end has came
            if checkAdded == -1
                break;
            end
            
            %now again mark the neighbours
            if isempty(baseNeigh)
               %nothing 
            else
                for i= 1: size(baseNeigh,2)
                    selectedId = baseNeigh(1,i);
                    
                    %search for the neigh of base vehicle is cluster and mark
                    for j = 1 : noOfVeh_T
                        if cluster_T(j,1) == selectedId
                            cluster_T(j,2) = 1;
                            break;
                        end
                    end
                end
            end
            
            clearvars baseNeigh;
            clearvars baseId;
            
        end
        
        clearvars baseNeigh;
        clearvars baseId;
        
    end
    
    clusterCountArray = [clusterCountArray clusterCount]
end


clusterCountArray_L500_C = clusterCountArray;
save ('clusterCountArray_L500_C.mat' , 'clusterCountArray_L500_C');

%% for range 100 Log Classical Model

load All_Neg_Data_Log_C.mat


AllNeighbours = All_Nodes_L100;


%time = 900 % for this time
%numberOfVehicles = 415; % for time 600 onwards
numberOfVehicles = 553;

clusterCountArray = [];
for time = 1005 : 10 :1799
    
    %since we have data till 1799, I am taking 1800 as 1799
    if time == 1800
        time = 1799;
    end
    time
    clusters = {};
    vehicles_T = AllNeighbours{time,1} ; %first colum veh ID and 2nd colum their neighbours
    noOfVeh_T = size(vehicles_T,1);
    
    %cluster_T contains information that will help in identifying cluster
    %1st row contain ID of vehicles
    %2nd row contain if vehicles selected
    %3rd row contains if neighbours of vehicles checked
    cluster_T = zeros(noOfVeh_T,3);
    
    %add nodes to the cluster array
    for i=1: noOfVeh_T
        if (isempty(vehicles_T{i,1}))
        else
            cluster_T(i,1) = vehicles_T{i,1};
        end
    end
    
    %% now check for clusters
    
    checkClusters = 1;
    clusterCount = 0;
    baseId = 0;
    baseNeigh = [];
    while checkClusters == 1
        checkClusters = -1;
        
        %check if the base vehicle exist
        for i= 1:noOfVeh_T
            if cluster_T(i,2) == 0 && cluster_T(i,3) == 0
                %vehicle selected
                cluster_T(i,2) = 1;
                cluster_T(i,3) = 1;
                %add neighbours
                baseId = cluster_T(i,1);
                baseNeigh = vehicles_T{i,2};
                checkClusters = 1;
                clusterCount = clusterCount+1;
                break;
            end
        end
        
        %check if the end has came
        if checkClusters == -1
            
            break;
        end
        
        %mark neighbors of base vehicle
        for i= 1: size(baseNeigh,2)
            selectedId = baseNeigh(1,i);
            %search for the neigh of base vehicle is cluster and mark
            for j = 1 : noOfVeh_T
                if cluster_T(j,1) == selectedId
                    cluster_T(j,2) = 1;
                    break;
                end
            end
        end
        
        clearvars baseNeigh;
        clearvars baseId;
        
        %check for all the vehicles that can be reached from here
        checkAdded = 1;
        while checkAdded == 1
            checkAdded = -1;
            %select the vehicle for base node again
            for i = 1 : noOfVeh_T
                if (cluster_T(i,2) == 1 && cluster_T(i,3) == 0)
                    baseId =  cluster_T(i,1);
                    baseNeigh = vehicles_T{i,2};
                    %base marked
                    cluster_T(i,3) = 1;
                    checkAdded = 1;
                    break;
                end
            end
            
            %check if the end has came
            if checkAdded == -1
                break;
            end
            
            %now again mark the neighbours
            if isempty(baseNeigh)
               %nothing 
            else
                for i= 1: size(baseNeigh,2)
                    selectedId = baseNeigh(1,i);
                    
                    %search for the neigh of base vehicle is cluster and mark
                    for j = 1 : noOfVeh_T
                        if cluster_T(j,1) == selectedId
                            cluster_T(j,2) = 1;
                            break;
                        end
                    end
                end
            end
            
            clearvars baseNeigh;
            clearvars baseId;
            
        end
        
        clearvars baseNeigh;
        clearvars baseId;
        
    end
    
    clusterCountArray = [clusterCountArray clusterCount]
end


clusterCountArray_L100_C = clusterCountArray;
save ('clusterCountArray_L100_C.mat' , 'clusterCountArray_L100_C');




%% FOR OBS MODEL %%

%% for range 500m OBS model
load All_Neg_Data_Obs.mat

AllNeighbours = All_Nodes_O500;

numberOfVehicles = 553;

clusterCountArray = [];
for time = 1005 : 10 :1799
    
    %since we have data till 1799, I am taking 1800 as 1799
    if time == 1800
        time = 1799;
    end
    time
    clusters = {};
    vehicles_T = AllNeighbours{time,1} ; %first colum veh ID and 2nd colum their neighbours
    noOfVeh_T = size(vehicles_T,1);
    
    %cluster_T contains information that will help in identifying cluster
    %1st row contain ID of vehicles
    %2nd row contain if vehicles selected
    %3rd row contains if neighbours of vehicles checked
    cluster_T = zeros(noOfVeh_T,3);
    
    %add nodes to the cluster array
    for i=1: noOfVeh_T
        if (isempty(vehicles_T{i,1}))
        else
            cluster_T(i,1) = vehicles_T{i,1};
        end
    end
    
    %% now check for clusters
    
    checkClusters = 1;
    clusterCount = 0;
    baseId = 0;
    baseNeigh = [];
    while checkClusters == 1
        checkClusters = -1;
        
        %check if the base vehicle exist
        for i= 1:noOfVeh_T
            if cluster_T(i,2) == 0 && cluster_T(i,3) == 0
                %vehicle selected
                cluster_T(i,2) = 1;
                cluster_T(i,3) = 1;
                %add neighbours
                baseId = cluster_T(i,1);
                baseNeigh = vehicles_T{i,2};
                checkClusters = 1;
                clusterCount = clusterCount+1;
                break;
            end
        end
        
        %check if the end has came
        if checkClusters == -1
            
            break;
        end
        
        %mark neighbors of base vehicle
        for i= 1: size(baseNeigh,2)
            selectedId = baseNeigh(1,i);
            %search for the neigh of base vehicle is cluster and mark
            for j = 1 : noOfVeh_T
                if cluster_T(j,1) == selectedId
                    cluster_T(j,2) = 1;
                    break;
                end
            end
        end
        
        clearvars baseNeigh;
        clearvars baseId;
        
        %check for all the vehicles that can be reached from here
        checkAdded = 1;
        while checkAdded == 1
            checkAdded = -1;
            %select the vehicle for base node again
            for i = 1 : noOfVeh_T
                if (cluster_T(i,2) == 1 && cluster_T(i,3) == 0)
                    baseId =  cluster_T(i,1);
                    baseNeigh = vehicles_T{i,2};
                    %base marked
                    cluster_T(i,3) = 1;
                    checkAdded = 1;
                    break;
                end
            end
            
            %check if the end has came
            if checkAdded == -1
                break;
            end
            
            %now again mark the neighbours
            if isempty(baseNeigh)
               %nothing 
            else
                for i= 1: size(baseNeigh,2)
                    selectedId = baseNeigh(1,i);
                    
                    %search for the neigh of base vehicle is cluster and mark
                    for j = 1 : noOfVeh_T
                        if cluster_T(j,1) == selectedId
                            cluster_T(j,2) = 1;
                            break;
                        end
                    end
                end
            end
            
            clearvars baseNeigh;
            clearvars baseId;
            
        end
        
        clearvars baseNeigh;
        clearvars baseId;
        
    end
    
    clusterCountArray = [clusterCountArray clusterCount]
end

clusterCountArray_O500 = clusterCountArray;
save ('clusterCountArray_O500.mat' , 'clusterCountArray_O500');

%% for range 100 Obs Model

load All_Neg_Data_Obs.mat


AllNeighbours = All_Nodes_O100;

%time = 900 % for this time
%numberOfVehicles = 415; % for time 600 onwards
numberOfVehicles = 553;

clusterCountArray = [];
for time = 1005 : 10 :1799
    
    %since we have data till 1799, I am taking 1800 as 1799
    if time == 1800
        time = 1799;
    end
    time
    clusters = {};
    vehicles_T = AllNeighbours{time,1} ; %first colum veh ID and 2nd colum their neighbours
    noOfVeh_T = size(vehicles_T,1);
    
    %cluster_T contains information that will help in identifying cluster
    %1st row contain ID of vehicles
    %2nd row contain if vehicles selected
    %3rd row contains if neighbours of vehicles checked
    cluster_T = zeros(noOfVeh_T,3);
    
    %add nodes to the cluster array
    for i=1: noOfVeh_T
        if (isempty(vehicles_T{i,1}))
        else
            cluster_T(i,1) = vehicles_T{i,1};
        end
    end
    
    %% now check for clusters
    
    checkClusters = 1;
    clusterCount = 0;
    baseId = 0;
    baseNeigh = [];
    while checkClusters == 1
        checkClusters = -1;
        
        %check if the base vehicle exist
        for i= 1:noOfVeh_T
            if cluster_T(i,2) == 0 && cluster_T(i,3) == 0
                %vehicle selected
                cluster_T(i,2) = 1;
                cluster_T(i,3) = 1;
                %add neighbours
                baseId = cluster_T(i,1);
                baseNeigh = vehicles_T{i,2};
                checkClusters = 1;
                clusterCount = clusterCount+1;
                break;
            end
        end
        
        %check if the end has came
        if checkClusters == -1
            
            break;
        end
        
        %mark neighbors of base vehicle
        for i= 1: size(baseNeigh,2)
            selectedId = baseNeigh(1,i);
            %search for the neigh of base vehicle is cluster and mark
            for j = 1 : noOfVeh_T
                if cluster_T(j,1) == selectedId
                    cluster_T(j,2) = 1;
                    break;
                end
            end
        end
        
        clearvars baseNeigh;
        clearvars baseId;
        
        %check for all the vehicles that can be reached from here
        checkAdded = 1;
        while checkAdded == 1
            checkAdded = -1;
            %select the vehicle for base node again
            for i = 1 : noOfVeh_T
                if (cluster_T(i,2) == 1 && cluster_T(i,3) == 0)
                    baseId =  cluster_T(i,1);
                    baseNeigh = vehicles_T{i,2};
                    %base marked
                    cluster_T(i,3) = 1;
                    checkAdded = 1;
                    break;
                end
            end
            
            %check if the end has came
            if checkAdded == -1
                break;
            end
            
            %now again mark the neighbours
            if isempty(baseNeigh)
               %nothing 
            else
                for i= 1: size(baseNeigh,2)
                    selectedId = baseNeigh(1,i);
                    
                    %search for the neigh of base vehicle is cluster and mark
                    for j = 1 : noOfVeh_T
                        if cluster_T(j,1) == selectedId
                            cluster_T(j,2) = 1;
                            break;
                        end
                    end
                end
            end
            
            clearvars baseNeigh;
            clearvars baseId;
            
        end
        
        clearvars baseNeigh;
        clearvars baseId;
        
    end
    
    clusterCountArray = [clusterCountArray clusterCount]
end


clusterCountArray_O100 = clusterCountArray;
save ('clusterCountArray_O100.mat' , 'clusterCountArray_O100');




%% FOR Unit Disk MODEL %%

%% for range 500m unit model
load All_Neg_Data_Unit.mat


AllNeighbours = All_Nodes_U500;


numberOfVehicles = 553;

clusterCountArray = [];
for time = 1005 : 10 :1799
    
    %since we have data till 1799, I am taking 1800 as 1799
    if time == 1800
        time = 1799;
    end
    time
    clusters = {};
    vehicles_T = AllNeighbours{time,1} ; %first colum veh ID and 2nd colum their neighbours
    noOfVeh_T = size(vehicles_T,1);
    
    %cluster_T contains information that will help in identifying cluster
    %1st row contain ID of vehicles
    %2nd row contain if vehicles selected
    %3rd row contains if neighbours of vehicles checked
    cluster_T = zeros(noOfVeh_T,3);
    
    %add nodes to the cluster array
    for i=1: noOfVeh_T
        if (isempty(vehicles_T{i,1}))
        else
            cluster_T(i,1) = vehicles_T{i,1};
        end
    end
    
    %% now check for clusters
    
    checkClusters = 1;
    clusterCount = 0;
    baseId = 0;
    baseNeigh = [];
    while checkClusters == 1
        checkClusters = -1;
        
        %check if the base vehicle exist
        for i= 1:noOfVeh_T
            if cluster_T(i,2) == 0 && cluster_T(i,3) == 0
                %vehicle selected
                cluster_T(i,2) = 1;
                cluster_T(i,3) = 1;
                %add neighbours
                baseId = cluster_T(i,1);
                baseNeigh = vehicles_T{i,2};
                checkClusters = 1;
                clusterCount = clusterCount+1;
                break;
            end
        end
        
        %check if the end has came
        if checkClusters == -1
            
            break;
        end
        
        %mark neighbors of base vehicle
        for i= 1: size(baseNeigh,2)
            selectedId = baseNeigh(1,i);
            %search for the neigh of base vehicle is cluster and mark
            for j = 1 : noOfVeh_T
                if cluster_T(j,1) == selectedId
                    cluster_T(j,2) = 1;
                    break;
                end
            end
        end
        
        clearvars baseNeigh;
        clearvars baseId;
        
        %check for all the vehicles that can be reached from here
        checkAdded = 1;
        while checkAdded == 1
            checkAdded = -1;
            %select the vehicle for base node again
            for i = 1 : noOfVeh_T
                if (cluster_T(i,2) == 1 && cluster_T(i,3) == 0)
                    baseId =  cluster_T(i,1);
                    baseNeigh = vehicles_T{i,2};
                    %base marked
                    cluster_T(i,3) = 1;
                    checkAdded = 1;
                    break;
                end
            end
            
            %check if the end has came
            if checkAdded == -1
                break;
            end
            
            %now again mark the neighbours
            if isempty(baseNeigh)
               %nothing 
            else
                for i= 1: size(baseNeigh,2)
                    selectedId = baseNeigh(1,i);
                    
                    %search for the neigh of base vehicle is cluster and mark
                    for j = 1 : noOfVeh_T
                        if cluster_T(j,1) == selectedId
                            cluster_T(j,2) = 1;
                            break;
                        end
                    end
                end
            end
            
            clearvars baseNeigh;
            clearvars baseId;
            
        end
        
        clearvars baseNeigh;
        clearvars baseId;
        
    end
    
    clusterCountArray = [clusterCountArray clusterCount]
end


clusterCountArray_U500 = clusterCountArray;
save ('clusterCountArray_U500.mat' , 'clusterCountArray_U500');

%% for range 100 Log Model

load All_Neg_Data_Unit.mat


AllNeighbours = All_Nodes_U100;

%time = 900 % for this time
%numberOfVehicles = 415; % for time 600 onwards
numberOfVehicles = 553;

clusterCountArray = [];
for time = 1005 : 10 :1799
    
    %since we have data till 1799, I am taking 1800 as 1799
    if time == 1800
        time = 1799;
    end
    time
    clusters = {};
    vehicles_T = AllNeighbours{time,1} ; %first colum veh ID and 2nd colum their neighbours
    noOfVeh_T = size(vehicles_T,1);
    
    %cluster_T contains information that will help in identifying cluster
    %1st row contain ID of vehicles
    %2nd row contain if vehicles selected
    %3rd row contains if neighbours of vehicles checked
    cluster_T = zeros(noOfVeh_T,3);
    
    %add nodes to the cluster array
    for i=1: noOfVeh_T
        if (isempty(vehicles_T{i,1}))
        else
            cluster_T(i,1) = vehicles_T{i,1};
        end
    end
    
    %% now check for clusters
    
    checkClusters = 1;
    clusterCount = 0;
    baseId = 0;
    baseNeigh = [];
    while checkClusters == 1
        checkClusters = -1;
        
        %check if the base vehicle exist
        for i= 1:noOfVeh_T
            if cluster_T(i,2) == 0 && cluster_T(i,3) == 0
                %vehicle selected
                cluster_T(i,2) = 1;
                cluster_T(i,3) = 1;
                %add neighbours
                baseId = cluster_T(i,1);
                baseNeigh = vehicles_T{i,2};
                checkClusters = 1;
                clusterCount = clusterCount+1;
                break;
            end
        end
        
        %check if the end has came
        if checkClusters == -1
            
            break;
        end
        
        %mark neighbors of base vehicle
        for i= 1: size(baseNeigh,2)
            selectedId = baseNeigh(1,i);
            %search for the neigh of base vehicle is cluster and mark
            for j = 1 : noOfVeh_T
                if cluster_T(j,1) == selectedId
                    cluster_T(j,2) = 1;
                    break;
                end
            end
        end
        
        clearvars baseNeigh;
        clearvars baseId;
        
        %check for all the vehicles that can be reached from here
        checkAdded = 1;
        while checkAdded == 1
            checkAdded = -1;
            %select the vehicle for base node again
            for i = 1 : noOfVeh_T
                if (cluster_T(i,2) == 1 && cluster_T(i,3) == 0)
                    baseId =  cluster_T(i,1);
                    baseNeigh = vehicles_T{i,2};
                    %base marked
                    cluster_T(i,3) = 1;
                    checkAdded = 1;
                    break;
                end
            end
            
            %check if the end has came
            if checkAdded == -1
                break;
            end
            
            %now again mark the neighbours
            if isempty(baseNeigh)
               %nothing 
            else
                for i= 1: size(baseNeigh,2)
                    selectedId = baseNeigh(1,i);
                    
                    %search for the neigh of base vehicle is cluster and mark
                    for j = 1 : noOfVeh_T
                        if cluster_T(j,1) == selectedId
                            cluster_T(j,2) = 1;
                            break;
                        end
                    end
                end
            end
            
            clearvars baseNeigh;
            clearvars baseId;
            
        end
        
        clearvars baseNeigh;
        clearvars baseId;
        
    end
    
    clusterCountArray = [clusterCountArray clusterCount]
end

clusterCountArray_U100 = clusterCountArray;
save ('clusterCountArray_U100.mat' , 'clusterCountArray_U100');

%}

%% NOW CDF MARKING

clear all;
clc;

load clusterCountArray_U100.mat
load clusterCountArray_U500.mat
load clusterCountArray_L100.mat
load clusterCountArray_L500.mat

load clusterCountArray_L100_C.mat
load clusterCountArray_L500_C.mat

load clusterCountArray_O100.mat
load clusterCountArray_O500.mat


figure

hold on;
box on
%% UNIT

U100 = cdfplot(clusterCountArray_U100);
U500 = cdfplot(clusterCountArray_U500);
set(U100,'color','b','LineStyle','-','Marker','o','LineWidth',1)
set(U500,'color','b','LineStyle',':','Marker','o','LineWidth', 2)

xdata = get(U100,'XData');
ydata = get(U100,'YData');
xdata(end)= xdata(end-1);
set(U100,'XData',xdata(2:2:end));
set(U100,'YData',ydata(2:2:end));

xdata = get(U500,'XData');
ydata = get(U500,'YData');
xdata(end)= xdata(end-1);
set(U500,'XData',xdata(2:2:end));
set(U500,'YData',ydata(2:2:end));


%% LOG

L100 = cdfplot(clusterCountArray_L100);
L500 = cdfplot(clusterCountArray_L500);
set(L100,'color','g','LineStyle','-','Marker','*','LineWidth',1)
set(L500,'color','g','LineStyle',':','Marker','*','LineWidth', 2)

xdata = get(L100,'XData');
ydata = get(L100,'YData');
xdata(end)= xdata(end-1);
set(L100,'XData',xdata(2:2:end));
set(L100,'YData',ydata(2:2:end));

xdata = get(L500,'XData');
ydata = get(L500,'YData');
xdata(end)= xdata(end-1);
set(L500,'XData',xdata(2:2:end));
set(L500,'YData',ydata(2:2:end));

%% LOG CLASSICAL

L100_C = cdfplot(clusterCountArray_L100_C);
L500_C = cdfplot(clusterCountArray_L500_C);
set(L100_C,'color','m','LineStyle','-','Marker','^','LineWidth',1)
set(L500_C,'color','m','LineStyle',':','Marker','^','LineWidth', 2)

xdata = get(L100_C,'XData');
ydata = get(L100_C,'YData');
xdata(end)= xdata(end-1);
set(L100_C,'XData',xdata(2:2:end));
set(L100_C,'YData',ydata(2:2:end));

xdata = get(L500_C,'XData');
ydata = get(L500_C,'YData');
xdata(end)= xdata(end-1);
set(L500_C,'XData',xdata(2:2:end));
set(L500_C,'YData',ydata(2:2:end));

%% OBSTACLE

O100 = cdfplot(clusterCountArray_O100);
O500 = cdfplot(clusterCountArray_O500);
set(O100,'color','r','LineStyle','-','Marker','s','LineWidth',1)
set(O500,'color','r','LineStyle',':','Marker','s','LineWidth', 2)

xdata = get(O100,'XData');
ydata = get(O100,'YData');
xdata(end)= xdata(end-1);
set(O100,'XData',xdata(2:2:end));
set(O100,'YData',ydata(2:2:end));

xdata = get(O500,'XData');
ydata = get(O500,'YData');
xdata(end)= xdata(end-1);
set(O500,'XData',xdata(2:2:end));
set(O500,'YData',ydata(2:2:end));

set(gca,'FontSize',12)

grid;
xlabel('No. of Clusters','FontSize',12);
ylabel('CDF','FontSize',12);
title('');

L = legend('Unit R=100m','Unit R=500m','Log_M R=100m', 'Log_M R=500m','Log_C R=100m', 'Log_C R=500m','Obs R=100m', 'Obs R=500m');
set(L,'FontSize',10);
