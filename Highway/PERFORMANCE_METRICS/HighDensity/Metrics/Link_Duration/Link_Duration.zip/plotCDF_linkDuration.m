clear all;
clc;

%% UNIT
load('LinkData_U500_high.mat');
load('LinkData_U100_high.mat');

siz100 = size(LinkData_U100,1)
siz500 = size(LinkData_U500,1);


linkDurations_U100 = zeros(siz100,1);
linkDurations_U500 = zeros(siz500,1);


for i = 1 : max(siz100,siz500)
    if i <= siz100
        linkDurations_U100(i,1) = LinkData_U100{i,1}(1,5);
        
    end
    if i <= siz500
        linkDurations_U500(i,1) = LinkData_U500{i,1}(1,5);
    end
end

disp('unit done');

%% OBSTACLE
load('LinkData_O500_high.mat');
load('LinkData_O100_high.mat');

siz100 = size(LinkData_O100,1)
siz500 = size(LinkData_O500,1);

linkDurations_O100 = zeros(siz100,1);
linkDurations_O500 = zeros(siz500,1);

for i = 1 : max(siz100,siz500)
    if i <= siz100
        linkDurations_O100(i,1) = LinkData_O100{i,1}(1,5);
        
    end
    if i <= siz500
        linkDurations_O500(i,1) = LinkData_O500{i,1}(1,5);
    end
end

disp('Obs done');

%% LOG NORMAL MODEL
load('LinkData_L500_high.mat');
load('LinkData_L100_high.mat');

siz100 = size(LinkData_L100,1);
siz500 = size(LinkData_L500,1);

linkDurations_L100 = zeros(siz100,1);
linkDurations_L500 = zeros(siz500,1);

for i = 1 : max(siz100,siz500)
    if i <= siz100
        linkDurations_L100(i,1) = LinkData_L100{i,1}(1,5);
    end
    if i <= siz500
        linkDurations_L500(i,1) = LinkData_L500{i,1}(1,5);
    end
end

disp('log done');

%% disp('Obs done');

%% LOG CLASSICAL MODEL
load('LinkData_L500_high_C.mat');
load('LinkData_L100_high_C.mat');

siz100 = size(LinkData_L100,1);
siz500 = size(LinkData_L500,1);

linkDurations_L100_C = zeros(siz100,1);
linkDurations_L500_C = zeros(siz500,1);

for i = 1 : max(siz100,siz500)
    if i <= siz100
        linkDurations_L100_C(i,1) = LinkData_L100{i,1}(1,5);
    end
    if i <= siz500
        linkDurations_L500_C(i,1) = LinkData_L500{i,1}(1,5);
    end
end

disp('log done');



figure

hold on;
box on;

%% UNIT
U100 = cdfplot(linkDurations_U100);
U500 = cdfplot(linkDurations_U500);

set(U100,'color','b','LineStyle','-','Marker','o','LineWidth',1)
set(U500,'color','b','LineStyle',':','Marker','o','LineWidth', 2)

xdata = get(U100,'XData');
ydata = get(U100,'YData');
set(U100,'XData',[xdata(1:2:5) xdata(5:30:end)]);
set(U100,'YData',[ydata(1:2:5) ydata(5:30:end)]);

xdata = get(U500,'XData');
ydata = get(U500,'YData');
set(U500,'XData',[xdata(1:2:5) xdata(5:30:end)]);
set(U500,'YData',[ydata(1:2:5) ydata(5:30:end)]);

%% LOG
L100 = cdfplot(linkDurations_L100);
L500 = cdfplot(linkDurations_L500);

set(L100,'color','g','LineStyle','-','Marker','*','LineWidth',1)
set(L500,'color','g','LineStyle',':','Marker','*','LineWidth', 2)

xdata = get(L100,'XData');
ydata = get(L100,'YData');
set(L100,'XData',[xdata(1:2:10) xdata(11:15:end)]);
set(L100,'YData',[ydata(1:2:10) ydata(11:15:end)]);

xdata = get(L500,'XData');
ydata = get(L500,'YData');
set(L500,'XData',[xdata(1:2:10) xdata(11:15:end)]);
set(L500,'YData',[ydata(1:2:10) ydata(11:15:end)]);

%% LOG CLASSICAL
L100_C = cdfplot(linkDurations_L100_C);
L500_C = cdfplot(linkDurations_L500_C);

set(L100_C,'color','m','LineStyle','-','Marker','^','LineWidth',1)
set(L500_C,'color','m','LineStyle',':','Marker','^','LineWidth', 2)

xdata = get(L100_C,'XData');
ydata = get(L100_C,'YData');
set(L100_C,'XData',[xdata(1:2:10) xdata(11:25:end)]);
set(L100_C,'YData',[ydata(1:2:10) ydata(11:25:end)]);

xdata = get(L500_C,'XData');
ydata = get(L500_C,'YData');
set(L500_C,'XData',[xdata(1:2:10) xdata(11:25:end)]);
set(L500_C,'YData',[ydata(1:2:10) ydata(11:25:end)]);

%% OBSTACLE
O100 = cdfplot(linkDurations_O100);
O500 = cdfplot(linkDurations_O500);
set(O100,'color','r','LineStyle','-','Marker','s','LineWidth',1)
set(O500,'color','r','LineStyle',':','Marker','s','LineWidth', 2)

xdata = get(O100,'XData');
ydata = get(O100,'YData');
set(O100,'XData',[xdata(1:2:5) xdata(5:20:end)]);
set(O100,'YData',[ydata(1:2:5) ydata(5:20:end)]);

xdata = get(O500,'XData');
ydata = get(O500,'YData');
set(O500,'XData',[xdata(1:2:5) xdata(5:20:end)]);
set(O500,'YData',[ydata(1:2:5) ydata(5:20:end)]);

%{
axis ([0 450 0 10000])
y = link_unit_New;
x = 1 :1: 450;
hist(y,x);
%}
grid;
xlabel('Link Duration (sec)');
ylabel('CDF');
title('Link Duration')
legend('Unit 100','Unit 500','Log_M 100', 'Log_M 500','Log_C 100', 'Log_C 500','Obstacle 100', 'Obstacle 500');




