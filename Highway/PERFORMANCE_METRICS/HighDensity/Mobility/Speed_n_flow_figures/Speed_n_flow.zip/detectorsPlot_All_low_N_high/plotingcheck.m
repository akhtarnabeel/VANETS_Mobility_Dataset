clear all
clc

d15r = [300   328   473   481   498   506   491];
d15r = d15r/5;

d15 = [486   486   486   486   486   486   486];
d15 = d15/5;


s1r =   [63.1882 61.1882   63.1613   61.0338   62.5753   61.9221   62.4840];

s1=[ 61.41423717 61.41423717 61.41423717 61.41423717 61.41423717 61.41423717 61.41423717 ];




s12r =[  63.0000   65.3175   64.8310   65.4293   66.5686   64.8701   64.8701]
s12r = s12r/5;

s12 =[   65.2400   65.2400   65.2400   65.2400   65.2400   65.2400   65.2400]
s12 = s12/5;   
   
   
   d3r =[    1    10    31    32    25    32    23 ]


d3 =[ 27.6600   27.6600   27.6600   27.6600   27.6600   27.6600   27.6600 ]




figure

time = [0 5 10 15 20 25 30]; 
 
hold on

axis ([0 30 0 80])
 
plot(time,s1,'--r*')
plot(time,s1r,'--b*')

plot(time,s12,'-r*')
plot(time,s12r,'-b*')

xlabel('minutes');
ylabel('speed');
title('Detector 1 Speed');


figure



hold on
axis ([0 30 0 200])
plot(time,d15,'-r*')
plot(time,d15r,'-b*')

plot(time,d3,'-r*')
plot(time,d3r,'-b*')


xlabel('minutes');
ylabel('vehicles');
title('Detector 15');


