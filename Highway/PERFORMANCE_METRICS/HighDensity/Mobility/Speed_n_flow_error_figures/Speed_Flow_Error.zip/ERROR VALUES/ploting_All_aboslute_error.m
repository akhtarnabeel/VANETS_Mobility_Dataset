clear all;
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% HIGH DENSITY

fin=fopen('output_trace_high.txt','r'); 
noOfLines = 38;

noVehicles = zeros(19,6);
noVehicles_actual = zeros(19,6);

avgSpeed = zeros(19,6);
avgSpeed_actual = zeros(19,6);

[data] = textread('output_trace_high.txt','','delimiter',' ');
counter =1 ;
for i = 1 :2: 38
    noVehicles(counter,:) = data(i,:);
    avgSpeed(counter,:) = data(i+1,:);
    counter = counter+1;
end    
    

%convert speed to miles\hour so we do following
avgSpeed = avgSpeed*2.2369;


 d1=[ 490  490 490 490 490 490];
 d2=[ 391.5  391.5 391.5 391.5 391.5 391.5];
 d3=[ 366.6  366.6 366.6 366.6 366.6 366.6];
 d4=[ 410 410 410 410 410 410 ];
 d5=[ 410 410 410 410 410 410];
 d6=[386.1 386.1 386.1 386.1 386.1 386.1 ];
 d7=[417 417 417 417 417  417 ];
 d8=[ 419 419 419 419 419 419 ];
 d9=[ 376 376 376 376 376 376  ];
 d10=[ 435 435 435 435 435 435 ];
 d11=[ 419 419 419 419 419 419 ];
 d12=[ 400 400 400 400 400 400];
 d13=[473 473 473 473 473 473];
 d14=[ 496 496 496 496 496 496 ];
 d15=[486 486 486 486 486 486];
 d16=[510 510 510 510 510 510];
 d17=[ 395 395 395 395 395 395];
 d18=[ 442 442 442 442 442 442];
 d19=[ 367 367 367 367 367 367];
 
%% Actaul Values
% No of Vehicles
 noVehicles_actual(1,:) = d1;
 noVehicles_actual(2,:) = d2;
 noVehicles_actual(3,:) = d3;
 noVehicles_actual(4,:) = d4;
 noVehicles_actual(5,:) = d5;
 noVehicles_actual(6,:) = d6;
 noVehicles_actual(7,:) = d7;
 noVehicles_actual(8,:) = d8;
 noVehicles_actual(9,:) = d9;
 noVehicles_actual(10,:) = d10;
 noVehicles_actual(11,:) = d11;
 noVehicles_actual(12,:) = d12;
 noVehicles_actual(13,:) = d13;
 noVehicles_actual(14,:) = d14;
 noVehicles_actual(15,:) = d15;
 noVehicles_actual(16,:) = d16;
 noVehicles_actual(17,:) = d17;
 noVehicles_actual(18,:) = d18;
 noVehicles_actual(19,:) = d19;
 
%% speed now

 s1=[ 61.41423717 61.41423717 61.41423717 61.41423717 61.41423717 61.41423717 ];
 s2=[ 59.47279693 59.47279693 59.47279693 59.47279693 59.47279693 59.47279693];
 s3=[59.95577273 59.95577273 59.95577273 59.95577273 59.95577273 59.95577273 ];
 s4=[ 67.77329341 67.77329341 67.77329341 67.77329341 67.77329341 67.77329341  ];
 s5=[ 58.79305324 58.79305324 58.79305324 58.79305324 58.79305324 58.79305324 ];
 s6=[59.32426437 59.32426437 59.32426437 59.32426437 59.32426437 59.32426437  ];
 s7=[56.92165402 56.92165402 56.92165402 56.92165402 56.92165402 56.92165402 ];
 s8=[58.56693164 58.56693164 58.56693164 58.56693164 58.56693164 58.56693164 ];
 s9=[54.99318282 54.99318282 54.99318282 54.99318282 54.99318282 54.99318282  ];
 s10=[ 59.57843738 59.57843738 59.57843738 59.57843738 59.57843738 59.57843738  ];
 s11=[59.74120923 59.74120923 59.74120923 59.74120923 59.74120923 59.74120923  ];
 s12=[59.99729617 59.99729617 59.99729617 59.99729617 59.99729617 59.99729617 ];
 s13=[57.16334507 57.16334507 57.16334507 57.16334507 57.16334507 57.16334507 ];
 s14=[58.44427276 58.44427276 58.44427276 58.44427276 58.44427276 58.44427276 ];
 s15=[62.82013009 62.82013009 62.82013009 62.82013009 62.82013009 62.82013009 ];
 s16=[62.12855276 62.12855276 62.12855276 62.12855276 62.12855276 62.12855276];
 s17=[60.18244726 60.18244726 60.18244726 60.18244726 60.18244726 60.18244726 ];
 s18=[59.52765637 59.52765637 59.52765637 59.52765637 59.52765637 59.52765637 ];
 s19=[59.58414137 59.58414137 59.58414137 59.58414137 59.58414137 59.58414137 ];
 
 %% Actual Values
 % No of Vehicles
 avgSpeed_actual(1,:) = s1;
 avgSpeed_actual(2,:) = s2;
 avgSpeed_actual(3,:) = s3;
 avgSpeed_actual(4,:) = s4;
 avgSpeed_actual(5,:) = s5;
 avgSpeed_actual(6,:) = s6;
 avgSpeed_actual(7,:) = s7;
 avgSpeed_actual(8,:) = s8;
 avgSpeed_actual(9,:) = s9;
 avgSpeed_actual(10,:) = s10;
 avgSpeed_actual(11,:) = s11;
 avgSpeed_actual(12,:) = s12;
 avgSpeed_actual(13,:) = s13;
 avgSpeed_actual(14,:) = s14;
 avgSpeed_actual(15,:) = s15;
 avgSpeed_actual(16,:) = s16;
 avgSpeed_actual(17,:) = s17;
 avgSpeed_actual(18,:) = s18;
 avgSpeed_actual(19,:) = s19; 
 
 
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% LOW DENSITY

 
 fin=fopen('output_trace_low.txt','r'); 
noOfLines = 38;

noVehicles_low = zeros(19,6);
noVehicles_actual_low = zeros(19,6);

avgSpeed_low = zeros(19,6);
avgSpeed_actual_low = zeros(19,6);

[data] = textread('output_trace_low.txt','','delimiter',' ');
counter =1 ;
for i = 1 :2: 38
    noVehicles_low(counter,:) = data(i,:);
    avgSpeed_low(counter,:) = data(i+1,:);
    counter = counter+1;
end    
    

%convert speed to miles\hour so we do following
avgSpeed_low = avgSpeed_low*2.2369;

 d1=[ 49.6  49.6 49.6 49.6 49.6 49.6];
 d2=[ 52.83 52.83 52.83 52.83 52.83 52.83 ];
 d3=[27.66 27.66 27.66 27.66 27.66 27.66];
 d4=[ 36.66 36.66 36.66 36.66 36.66 36.66 ];
 d5=[ 100 100 100 100 100 100]; %%
 d6=[32.5 32.5 32.5 32.5 32.5 32.5  ];
 d7=[43.833 43.833 43.833 43.833 43.833 43.833 ];
 d8=[ 39.16 39.16 39.16 39.16 39.16 39.16 ];
 d9=[ 376 376 376 376 376 376  ]; %%
 d10=[ 36.833 36.833 36.833 36.833 36.833 36.833  ];
 d11=[ 34.166 34.166 34.166 34.166 34.166 34.166  ];
 d12=[ 38.33 38.33 38.33 38.33 38.33 38.33 ];
 d13=[46 46 46 46 46 46];
 d14=[ 46 46 46 46 46 46 ];
 d15=[57.66 57.66 57.66 57.66 57.66 57.66 ];
 d16=[510 510 510 510 510  510]; %%
 d17=[ 395 395 395  395 395 395 ]; %%
 d18=[ 46.833 46.833 46.833 46.833 46.833 46.833 ];
 d19=[ 68.333 68.333 68.333 68.333 68.333 68.333 ]; %%
 
%% Actaul Values
% No of Vehicles
 noVehicles_actual_low(1,:) = d1;
 noVehicles_actual_low(2,:) = d2;
 noVehicles_actual_low(3,:) = d3;
 noVehicles_actual_low(4,:) = d4;
 noVehicles_actual_low(5,:) = d5;
 noVehicles_actual_low(6,:) = d6;
 noVehicles_actual_low(7,:) = d7;
 noVehicles_actual_low(8,:) = d8;
 noVehicles_actual_low(9,:) = d9;
 noVehicles_actual_low(10,:) = d10;
 noVehicles_actual_low(11,:) = d11;
 noVehicles_actual_low(12,:) = d12;
 noVehicles_actual_low(13,:) = d13;
 noVehicles_actual_low(14,:) = d14;
 noVehicles_actual_low(15,:) = d15;
 noVehicles_actual_low(16,:) = d16;
 noVehicles_actual_low(17,:) = d17;
 noVehicles_actual_low(18,:) = d18;
 noVehicles_actual_low(19,:) = d19;
 
%% speed now


 s1=[ 65.95 65.95 65.95 65.95 65.95 65.95 ];
 s2=[ 69.9 69.9 69.9 69.9 69.9 69.9 ];
 s3=[64 64 64 64 64 64 ];
 s4=[ 67.23 67.23 67.23 67.23 67.23 67.23  ];
 s5=[ 62.6 62.6 62.6 62.6 62.6 62.6 ]; %%
 s6=[64.46 64.46 64.46 64.46 64.46 64.46  ];
 s7=[57.4 57.4 57.4 57.4 57.4 57.4 ];
 s8=[63.62 63.62 63.62 63.62 63.62 63.62 ];
 s9=[60.6 60.6 60.6 60.6 60.6 60.6  ]; %%
 s10=[65.63 65.63 65.63 65.63 65.63 65.63  ];
 s11=[66.54 66.54 66.54 66.54 66.54 66.54  ];
 s12=[65.24 65.24 65.24 65.24 65.24 65.24 ];
 s13=[65.72 65.72 65.72 65.72 65.72 65.72 ];
 s14=[66.9 66.9 66.9 66.9 66.9 66.9 ];
 s15=[65.7 65.7 65.7 65.7 65.7 65.7 ];
 s16=[000 000 000 000 000 000]; %%
 s17=[000 000 000 000 000 000 ]; %%
 s18=[71.89 71.89 71.89 71.89 71.89 71.89 ];
 s19=[000 000 000 000 000 000 ]; %%
 
 %% Actual Values
 % No of Vehicles
 avgSpeed_actual_low(1,:) = s1;
 avgSpeed_actual_low(2,:) = s2;
 avgSpeed_actual_low(3,:) = s3;
 avgSpeed_actual_low(4,:) = s4;
 avgSpeed_actual_low(5,:) = s5;
 avgSpeed_actual_low(6,:) = s6;
 avgSpeed_actual_low(7,:) = s7;
 avgSpeed_actual_low(8,:) = s8;
 avgSpeed_actual_low(9,:) = s9;
 avgSpeed_actual_low(10,:) = s10;
 avgSpeed_actual_low(11,:) = s11;
 avgSpeed_actual_low(12,:) = s12;
 avgSpeed_actual_low(13,:) = s13;
 avgSpeed_actual_low(14,:) = s14;
 avgSpeed_actual_low(15,:) = s15;
 avgSpeed_actual_low(16,:) = s16;
 avgSpeed_actual_low(17,:) = s17;
 avgSpeed_actual_low(18,:) = s18;
 avgSpeed_actual_low(19,:) = s19; 
 
 
%% calculations high density

 error_noVeh_high = zeros(19*6);
 counter = 0;
 
 error_speed_high = zeros(19*6);
 
 %for all time values 
 for j=1:6
     if j <= 2
         continue;
     end
     %for all sensors
     for i=1:19
         counter = counter+1;
         %error_noVeh_high(counter) = abs(noVehicles(i,j)-noVehicles_actual(i,j))/noVehicles_actual(i,j)*100;
         %error_speed_high(counter) =  abs(avgSpeed_actual(i,j)-avgSpeed(i,j))/avgSpeed_actual(i,j)*100;     
         error_noVeh_high(counter) = (abs(noVehicles(i,j)-noVehicles_actual(i,j)))/5;
         error_speed_high(counter) =  abs(avgSpeed_actual(i,j)-avgSpeed(i,j));     
     end
 end
  %% to adjust graphs
 counter = counter+1;
 error_noVeh_high(counter) = 400;
 error_speed_high(counter) = 25;
 
 
 error_noVeh_high = error_noVeh_high(1:counter);
 error_speed_high = error_speed_high(1:counter);

 
%% calculations low density
 
 error_noVeh_low = zeros(19*6);
 counter = 0;
 
 error_speed_low = zeros(19*6);
 
 %for all time values 
 for j=1:6
     if j <= 2
         continue;
     end
     %for all sensors
     for i=1:19
         if (i==5 || i==9 || i==16 || i == 17 || i == 19)
            continue;
         end
         counter = counter+1;
         %error_noVeh_low(counter) = abs(noVehicles_low(i,j)-noVehicles_actual_low(i,j))/noVehicles_actual_low(i,j)*100;
         %error_speed_low(counter) =  abs(avgSpeed_actual_low(i,j)-avgSpeed_low(i,j))/avgSpeed_actual_low(i,j)*100;     
         error_noVeh_low(counter) = (abs(noVehicles_low(i,j)-noVehicles_actual_low(i,j)))/5;
         error_speed_low(counter) =  abs(avgSpeed_actual_low(i,j)-avgSpeed_low(i,j));     
     
     end
 end
 
 %% to adjust graphs
 counter = counter+1;
 error_noVeh_low(counter) = 400;
 error_speed_low(counter) = 25;
 
 
 error_noVeh_low = error_noVeh_low(1:counter);
 error_speed_low = error_speed_low(1:counter);

 
%% Draw Figures 
%{
%% FLOW
figure
hold on;
box on;

axis ([0 350 0 1])


veh_cdf_low = cdfplot(error_noVeh_low);
veh_cdf = cdfplot(error_noVeh_high);

set(veh_cdf,'color','r','LineStyle','-','LineWidth',1);
set(veh_cdf_low,'color','b','LineStyle',':','LineWidth',2);

% high density

xdata = get(veh_cdf,'XData');
ydata = get(veh_cdf,'YData');
set(veh_cdf,'XData',xdata(1:2:end));
set(veh_cdf,'YData',ydata(1:2:end));

% low density

xdata = get(veh_cdf_low,'XData');
ydata = get(veh_cdf_low,'YData');
set(veh_cdf_low,'XData',xdata(1:2:end));
set(veh_cdf_low,'YData',ydata(1:2:end));

set(gca,'FontSize',12)

grid;

xlabel('Average Flow Error (No. of vehicles)','FontSize',12);
ylabel('CDF','FontSize',12);
title('')
L = legend('LowDensity', 'HighDensity');
set(L,'FontSize',12);


%% SPEED
figure
hold on;
box on;

axis ([0 20 0 1])

speed_cdf_low = cdfplot(error_speed_low);
speed_cdf = cdfplot(error_speed_high);

set(speed_cdf,'color','r','LineStyle','-','LineWidth',1)
set(speed_cdf_low,'color','b','LineStyle',':','LineWidth',2)

% high density
xdata = get(speed_cdf,'XData');
ydata = get(speed_cdf,'YData');
set(speed_cdf,'XData',xdata(1:2:end));
set(speed_cdf,'YData',ydata(1:2:end));

% low density
xdata = get(speed_cdf_low,'XData');
ydata = get(speed_cdf_low,'YData');
%set(speed_cdf_low,'XData',[xdata(1:11:end) xdata(end-1)]);
%set(speed_cdf_low,'YData',[ydata(1:11:end) ydata(end-1)]);
set(speed_cdf,'XData',xdata(1:2:end));
set(speed_cdf,'YData',ydata(1:2:end));

set(gca,'FontSize',12)

grid;

xlabel('Average Speed Error (mph)','FontSize',12);
ylabel('CDF','FontSize',12);
title('')
L = legend('LowDensity','HighDensity');
set(L,'FontSize',12);


%}

%%
%%%%%%%%%%%%%
%% Draw Figures
figure
hold on;
box on;

axis ([0 30 0 1])

veh_cdf = cdfplot(error_noVeh_high);
speed_cdf = cdfplot(error_speed_high);


set(veh_cdf,'color','b','LineStyle','-','Marker','x','LineWidth',1);
set(speed_cdf,'color','r','LineStyle','-','Marker','s','LineWidth',1)

% high density

xdata = get(veh_cdf,'XData');
ydata = get(veh_cdf,'YData');
set(veh_cdf,'XData',[xdata(1:3) xdata(3:8:end)]);
set(veh_cdf,'YData',[ydata(1:3) ydata(3:8:end)]);
%set(veh_cdf,'XData',xdata(1:2:end));
%set(veh_cdf,'YData',ydata(1:2:end));

xdata = get(speed_cdf,'XData');
ydata = get(speed_cdf,'YData');
%set(speed_cdf,'XData',xdata(1:2:end));
%set(speed_cdf,'YData',ydata(1:2:end));
set(speed_cdf,'XData',[xdata(1:3) xdata(3:8:end/1.25) xdata(end/1.25:5:end-2) xdata(end-2:end)] );
set(speed_cdf,'YData',[ydata(1:3) ydata(3:8:end/1.25) ydata(end/1.25:5:end-2) ydata(end-2:end)]);


set(gca,'FontSize',12)

grid;

xlabel('Percentage Error','FontSize',12);
ylabel('CDF','FontSize',12);
title('')
L = legend('Flow', 'Speed');
set(L,'FontSize',12);

%% LOW DENSITY
figure
hold on;
box on;

axis ([0 30 0 1])

veh_cdf_low = cdfplot(error_noVeh_low);
speed_cdf_low = cdfplot(error_speed_low);


set(veh_cdf_low,'color','b','LineStyle',':','Marker','x','LineWidth',2);
set(speed_cdf_low,'color','r','LineStyle',':','Marker','s','LineWidth',2)

% low density

xdata = get(veh_cdf_low,'XData');
ydata = get(veh_cdf_low,'YData');
%set(veh_cdf_low,'XData',xdata(1:4:end));
%set(veh_cdf_low,'YData',ydata(1:4:end));
set(veh_cdf_low,'XData',[xdata(1:8:end) xdata(end-1)]);
set(veh_cdf_low,'YData',[ydata(1:8:end) ydata(end-1)]);

xdata = get(speed_cdf_low,'XData');
ydata = get(speed_cdf_low,'YData');
%set(speed_cdf_low,'XData',[xdata(1:4:end) ]);
%set(speed_cdf_low,'YData',[ydata(1:4:end) ]);
set(speed_cdf_low,'XData',[xdata(1:8:end) xdata(end-1)]);
set(speed_cdf_low,'YData',[ydata(1:8:end) ydata(end-1)]);

set(gca,'FontSize',12)

grid;

xlabel('Percentage Error','FontSize',12);
ylabel('CDF','FontSize',12);
title('')
L = legend('Flow', 'Speed');
set(L,'FontSize',12);

