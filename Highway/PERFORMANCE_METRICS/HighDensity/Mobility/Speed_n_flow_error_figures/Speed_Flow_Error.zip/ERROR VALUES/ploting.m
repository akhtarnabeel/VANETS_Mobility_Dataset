clear all;
clc


fin=fopen('output_trace_low.txt','r'); 
noOfLines = 38;

noVehicles = zeros(19,6);

avgSpeed = zeros(19,6);

[data] = textread('output_trace_low.txt','','delimiter',' ');
counter =1 
for i = 1 :2: 38
    noVehicles(counter,:) = data(i,:);
    avgSpeed(counter,:) = data(i+1,:);
    counter = counter+1;
end    
    

%convert speed to miles\hour so we do following
avgSpeed = avgSpeed*2.2369;


 d1=[ 49.6  49.6 49.6 49.6 49.6 49.6];
 d1r=noVehicles(1,:)
 
 
 d2=[ 52.83 52.83 52.83 52.83 52.83 52.83 ];
 d2r=noVehicles(2,:)
 
 
 d3=[27.66 27.66 27.66 27.66 27.66 27.66 27.66 ];
 d3r=noVehicles(3,:)
 
 
 d4=[ 36.66 36.66 36.66 36.66 36.66 36.66 ];
 d4r=noVehicles(4,:)
 
 
 d5=[ 100 100 100 100 100 100];
 d5r=noVehicles(5,:)
 
 d6=[32.5 32.5 32.5 32.5 32.5 32.5  ];
 d6r=noVehicles(6,:)
 
 
 d7=[43.833 43.833 43.833 43.833 43.833 43.833 ];
 d7r=noVehicles(7,:);
 
 d8=[ 39.16 39.16 39.16 39.16 39.16 39.16 ];
 d8r=noVehicles(8,:)
 
 
 d9=[ 376 376 376 376 376 376  ];
 d9r=noVehicles(9,:)
 
 
 d10=[ 36.833 36.833 36.833 36.833 36.833 36.833  ];
 d10r=noVehicles(10,:)
 
 
 d11=[ 34.166 34.166 34.166 34.166 34.166 34.166  ];
 d11r=noVehicles(11,:)
 
 
 d12=[ 38.33 38.33 38.33 38.33 38.33 38.33 ];
 d12r=noVehicles(12,:)
 
 
 d13=[46 46 46 46 46 46];
 d13r=noVehicles(13,:)
 
 
 d14=[ 46 46 46 46 46 46 ];
 d14r=noVehicles(14,:)
 
 
 d15=[57.66 57.66 57.66 57.66 57.66 57.66 ];
 d15r=noVehicles(15,:)
 
 d16=[510 510 510 510 510  510];
 d16r=noVehicles(16,:)
 
 
 d17=[ 395 395 395  395 395 395 ];
 d17r=noVehicles(17,:)
 
 
 d18=[ 46.833 46.833 46.833 46.833 46.833 46.833 ];
 d18r=noVehicles(18,:)
 
 
 d19=[ 68.333 68.333 68.333 68.333 68.333 68.333 ];
 d19r=noVehicles(19,:)
 

time = [5 10 15 20 25 30]; 
 
hold on

axis ([0 30 0 150])
 
plot(time,d1,'-r*')
plot(time,d1r,'-b*')
xlabel('minutes');
ylabel('vehicles');
title('Detector 1');

figure

hold on
axis ([0 30 0 150])

plot(time,d2,'-r*')
plot(time,d2r,'-b*')
xlabel('minutes');
ylabel('vehicles');
title('Detector 2');

figure

hold on
axis ([0 30 0 150])
time1 = [0 time];
disp('*******************************');
d3r = [1 d3r]
d3
plot(time1,d3,'-r*')
plot(time1,d3r,'-b*')
xlabel('Time (minutes)');
ylabel('Flow (vehicles/5mins)');
title('Detector');


figure

hold on
axis ([0 30 0 150])
plot(time,d4,'-r*')
plot(time,d4r,'-b*')
xlabel('minutes');
ylabel('vehicles');
title('Detector 4');


figure

hold on
axis ([0 30 0 150])
plot(time,d5,'-r*')
plot(time,d5r,'-b*')
xlabel('minutes');
ylabel('vehicles');
title('Detector 5');



figure

hold on
axis ([0 30 0 150])

plot(time,d6,'-r*')
plot(time,d6r,'-b*')
xlabel('minutes');
ylabel('vehicles');
title('Detector 6');

figure

hold on
axis ([0 30 0 150])

plot(time,d7,'-r*')
plot(time,d7r,'-b*')
xlabel('minutes');
ylabel('vehicles');
title('Detector 7');


figure

hold on
axis ([0 30 0 150])

plot(time,d8,'-r*')
plot(time,d8r,'-b*')
xlabel('minutes');
ylabel('vehicles');
title('Detector 8');


figure

hold on
axis ([0 30 0 150])
plot(time,d9,'-r*')
plot(time,d9r,'-b*')
xlabel('minutes');
ylabel('vehicles');
title('Detector 9');


figure
hold on
axis ([0 30 0 150])
plot(time,d10,'-r*')
plot(time,d10r,'-b*')
xlabel('minutes');
ylabel('vehicles');
title('Detector 10');

figure
hold on
axis ([0 30 0 150])
plot(time,d11,'-r*')
plot(time,d11r,'-b*')
xlabel('minutes');
ylabel('vehicles');
title('Detector 11');

figure

hold on
axis ([0 30 0 150])
plot(time,d12,'-r*')
plot(time,d12r,'-b*')
xlabel('minutes');
ylabel('vehicles');
title('Detector 12');

figure

hold on
axis ([0 30 0 150])
plot(time,d13,'-r*')
plot(time,d13r,'-b*')
xlabel('minutes');
ylabel('vehicles');
title('Detector 13');


figure

hold on
axis ([0 30 0 150])
plot(time,d14,'-r*')
plot(time,d14r,'-b*')
xlabel('minutes');
ylabel('vehicles');
title('Detector 14');


figure

hold on
axis ([0 30 0 150])
plot(time,d15,'-r*')
plot(time,d15r,'-b*')
xlabel('minutes');
ylabel('vehicles');
title('Detector 15');



figure

hold on
axis ([0 30 0 150])
plot(time,d16,'-r*')
plot(time,d16r,'-b*')
xlabel('minutes');
ylabel('vehicles');
title('Detector 16');

figure

hold on
axis ([0 30 0 150])
plot(time,d17,'-r*')
plot(time,d17r,'-b*')
xlabel('minutes');
ylabel('vehicles');
title('Detector 17');


figure

hold on
axis ([0 30 0 150])

plot(time,d18,'-r*')
plot(time,d18r,'-b*')
xlabel('minutes');
ylabel('vehicles');
title('Detector 18');


figure

hold on
axis ([0 30 0 150])
plot(time,d19,'-r*')
plot(time,d19r,'-b*')
xlabel('minutes');
ylabel('vehicles');
title('Detector 19');


%% speed now

 s1=[ 65.95 65.95 65.95 65.95 65.95 65.95 ];
 s1r=avgSpeed(1,:)
 
 
 s2=[ 69.9 69.9 69.9 69.9 69.9 69.9 ];
 s2r=avgSpeed(2,:)
 
 
 s3=[64 64 64 64 64 64 ];
 s3r=avgSpeed(3,:)
 
 
 s4=[ 67.23 67.23 67.23 67.23 67.23 67.23  ];
 s4r=avgSpeed(4,:)
 
 
 s5=[ 62.6 62.6 62.6 62.6 62.6 62.6 ];
 s5r=avgSpeed(5,:)
 
 s6=[64.46 64.46 64.46 64.46 64.46 64.46  ];
 s6r=avgSpeed(6,:)
 
 
 s7=[57.4 57.4 57.4 57.4 57.4 57.4 ];
 s7r=avgSpeed(7,:);
 
 s8=[63.62 63.62 63.62 63.62 63.62 63.62 ];
 s8r=avgSpeed(8,:)
 
 
 s9=[60.6 60.6 60.6 60.6 60.6 60.6  ];
 s9r=avgSpeed(9,:)
 
 
 s10=[65.63 65.63 65.63 65.63 65.63 65.63  ];
 s10r=avgSpeed(10,:)
 
 
 s11=[66.54 66.54 66.54 66.54 66.54 66.54  ];
 s11r=avgSpeed(11,:)
 
 
 s12=[65.24 65.24 65.24 65.24 65.24 65.24 65.24 ];
 s12r=avgSpeed(12,:)
 
 
 s13=[65.72 65.72 65.72 65.72 65.72 65.72 ];
 s13r=avgSpeed(13,:)
 
 
 s14=[66.9 66.9 66.9 66.9 66.9 66.9 ];
 s14r=avgSpeed(14,:)
 
 
 s15=[65.7 65.7 65.7 65.7 65.7 65.7 ];
 s15r=avgSpeed(15,:)
 
 s16=[000 000 000 000 000 000];
 s16r=avgSpeed(16,:)
 
 
 s17=[000 000 000 000 000 000 ];
 s17r=avgSpeed(17,:)
 
 
 s18=[71.89 71.89 71.89 71.89 71.89 71.89 ];
 s18r=avgSpeed(18,:)
 
 
 s19=[000 000 000 000 000 000 ];
 s19r=avgSpeed(19,:)
 

time = [5 10 15 20 25 30]; 

figure

hold on

axis ([0 30 0 80])
 
plot(time,s1,'-r*')
plot(time,s1r,'-b*')
xlabel('minutes');
ylabel('speed');
title('Detector 1 Speed');

figure

hold on
axis ([0 30 0 80])

plot(time,s2,'-r*')
plot(time,s2r,'-b*')
xlabel('minutes');
ylabel(' Speed');
title('Detector 2 Speed');

figure

hold on
axis ([0 30 0 80])

plot(time,s3,'-r*')
plot(time,s3r,'-b*')
xlabel('minutes');
ylabel(' Speed');
title('Detector 3 Speed');


figure

hold on
axis ([0 30 0 80])
plot(time,s4,'-r*')
plot(time,s4r,'-b*')
xlabel('minutes');
ylabel(' Speed');
title('Detector 4 Speed');


figure

hold on
axis ([0 30 0 80])
plot(time,s5,'-r*')
plot(time,s5r,'-b*')
xlabel('minutes');
ylabel(' Speed');
title('Detector 5 Speed');



figure

hold on
axis ([0 30 0 80])

plot(time,s6,'-r*')
plot(time,s6r,'-b*')
xlabel('minutes');
ylabel(' Speed');
title('Detector 6 Speed');

figure

hold on
axis ([0 30 0 80])

plot(time,s7,'-r*')
plot(time,s7r,'-b*')
xlabel('minutes');
ylabel(' Speed');
title('Detector 7 Speed');


figure

hold on
axis ([0 30 0 80])

plot(time,s8,'-r*')
plot(time,s8r,'-b*')
xlabel('minutes');
ylabel(' Speed');
title('Detector 8 Speed');


figure

hold on
axis ([0 30 0 80])
plot(time,s9,'-r*')
plot(time,s9r,'-b*')
xlabel('minutes');
ylabel(' Speed');
title('Detector 9 Speed');


figure
hold on
axis ([0 30 0 80])
plot(time,s10,'-r*')
plot(time,s10r,'-b*')
xlabel('minutes');
ylabel(' Speed');
title('Detector 10 Speed');

figure
hold on
axis ([0 30 0 80])
plot(time,s11,'-r*')
plot(time,s11r,'-b*')
xlabel('minutes');
ylabel(' Speed');
title('Detector 11 Speed');

figure

hold on
axis ([0 30 0 80])
disp('*******************')
time1 = [0 time] 
s12r = [63 s12r]
s12
plot(time1,s12,'-r*')
plot(time1,s12r,'-b*')
xlabel('minutes');
ylabel(' Speed');
title('Detector 12 Speed');

figure

hold on
axis ([0 30 0 80])
plot(time,s13,'-r*')
plot(time,s13r,'-b*')
xlabel('minutes');
ylabel(' Speed');
title('Detector 13 Speed');


figure

hold on
axis ([0 30 0 80])
plot(time,s14,'-r*')
plot(time,s14r,'-b*')
xlabel('minutes');
ylabel(' Speed');
title('Detector 14 Speed');


figure

hold on
axis ([0 30 0 80])
plot(time,s15,'-r*')
plot(time,s15r,'-b*')
xlabel('minutes');
ylabel(' Speed');
title('Detector 15 Speed');



figure

hold on
axis ([0 30 0 80])
plot(time,s16,'-r*')
plot(time,s16r,'-b*')
xlabel('minutes');
ylabel(' Speed');
title('Detector 16 Speed');

figure

hold on
axis ([0 30 0 80])
plot(time,s17,'-r*')
plot(time,s17r,'-b*')
xlabel('minutes');
ylabel(' Speed');
title('Detector 17 Speed');


figure

hold on
axis ([0 30 0 80])

plot(time,s18,'-r*')
plot(time,s18r,'-b*')
xlabel('minutes');
ylabel(' Speed');
title('Detector 18 Speed');


figure

hold on
axis ([0 30 0 80])
plot(time,s19,'-r*')
plot(time,s19r,'-b*')
xlabel('minutes');
ylabel(' Speed');
title('Detector 19 Speed');

